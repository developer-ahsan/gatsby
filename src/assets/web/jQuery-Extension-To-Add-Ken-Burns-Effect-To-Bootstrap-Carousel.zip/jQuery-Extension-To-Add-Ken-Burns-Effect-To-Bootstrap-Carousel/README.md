# bootstrap-kenbruns-carousel
Bootstrap carousel effect Ken Bruns
Everything is standard. See the source code. Read more on the website http://filwebs.ru/bootstrap-kenbruns-carousel/ <br>
<h2>DEMO</h2> http://filwebs.ru/demo/bootstrap-kenbruns-carousel/
